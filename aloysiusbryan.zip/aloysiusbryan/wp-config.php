<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the installation.
 * You don't have to use the web site, you can copy this file to "wp-config.php"
 * and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://wordpress.org/support/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'aloysiusbryan' );

/** MySQL database username */
define( 'DB_USER', 'root' );

/** MySQL database password */
define( 'DB_PASSWORD', '' );

/** MySQL hostname */
define( 'DB_HOST', 'localhost' );

/** Database charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The database collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication unique keys and salts.
 *
 * Change these to different unique phrases! You can generate these using
 * the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}.
 *
 * You can change these at any point in time to invalidate all existing cookies.
 * This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         'moV;$QT.U04MvJ_=ls>UE=nFF.<LUX*=n=~X3]LP%1L3.7(Ah4mz> 7Rk]qmc]4s' );
define( 'SECURE_AUTH_KEY',  'xunW:Rr>F5!6SZ0{Z?~Z AvTx$)L0GGY@1 8FQ^5KLGB[<RE[?y6<Mf%^AQ:+TR1' );
define( 'LOGGED_IN_KEY',    'tG! U:BeBuB$U*K|`{6%}ZylD(S8D%<H;ffV_c)pd2`d9aqJ5UOl;3OQ-Kgk|>#?' );
define( 'NONCE_KEY',        ']m)}~f!A5*.P.f9GuPTmU;asi]>}epB;@HQC N=->NaM-8Oxj#(&d^yNBd3,riDx' );
define( 'AUTH_SALT',        '{;SAM:`*dAO:U@60*7C;ccQi`/_V6B{S|=S?ccLxsa{}CRlNLN/7x[IBZ&v&?vcj' );
define( 'SECURE_AUTH_SALT', 'g_4_,DPON9!wx7)P6SMPH?34bn#6Z@/E, Vmz?K/16Kao(nsYu!{&0T|Q8|MLPKT' );
define( 'LOGGED_IN_SALT',   'UP, }|f?Ml?g RFDtIQ`FlCrqx*HN@PM7(:iB/Rx7qaDev-oNlwD=~&ZFbsgZT.I' );
define( 'NONCE_SALT',       'vN,qW&us_*uiCMZmRLVStiWL/LZ?:L,5b~CRGf`.c*#/hzi-}OL~ hfu%BLP?WKX' );

/**#@-*/

/**
 * WordPress database table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/support/article/debugging-in-wordpress/
 */
define( 'WP_DEBUG', false );

/* Add any custom values between this line and the "stop editing" line. */



/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
